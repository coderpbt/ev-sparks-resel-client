// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDNiRWZLF4HpCKKD9axWKK-JkCfs-TpUkM",
  authDomain: "evspark22.firebaseapp.com",
  projectId: "evspark22",
  storageBucket: "evspark22.appspot.com",
  messagingSenderId: "364543601224",
  appId: "1:364543601224:web:2619905362dd0297a0067d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;