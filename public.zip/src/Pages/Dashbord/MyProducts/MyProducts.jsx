import React from 'react';

const MyProducts = () => {
  return (
    <div>
      <h2>My Products</h2>
    </div>
  );
};

export default MyProducts;